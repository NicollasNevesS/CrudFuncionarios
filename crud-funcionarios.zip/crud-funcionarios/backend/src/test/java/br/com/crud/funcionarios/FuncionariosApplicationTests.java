package br.com.crud.funcionarios;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FuncionariosApplicationTests {

	@Test
	void contextLoads() {
	}

}
