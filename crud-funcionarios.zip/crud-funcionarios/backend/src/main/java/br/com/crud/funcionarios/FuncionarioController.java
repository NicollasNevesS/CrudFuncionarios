
package br.com.crud.funcionarios;

import jakarta.validation.Valid;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@RestController
@RequestMapping("/api/funcionarios")
public class FuncionarioController {

    private final FuncionarioRepository repository;

    public FuncionarioController(FuncionarioRepository repository) {
        this.repository = repository;
    }

    @GetMapping
    public List<Funcionario> listar() {
        return repository.findAll();
    }

    @GetMapping("/{id}")
    public Funcionario buscar(@PathVariable Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Funcionário não encontrado"
                ));
    }

    @PostMapping
    public ResponseEntity<?> criar(
            @Valid @RequestBody Funcionario funcionario) {

        funcionario.setCpf(normalizarCpf(funcionario.getCpf()));

        if (repository.existsByCpf(funcionario.getCpf())) {
            return ResponseEntity.status(HttpStatus.CONFLICT)
                    .body("Já existe um funcionário com esse CPF");
        }

        try {
            return ResponseEntity.status(HttpStatus.CREATED)
                    .body(repository.save(funcionario));
        } catch (DataIntegrityViolationException e) {
            return ResponseEntity.status(HttpStatus.CONFLICT)
                    .body("Já existe um funcionário com esse CPF");
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> atualizar(
            @PathVariable Long id,
            @Valid @RequestBody Funcionario dados) {

        Funcionario atual = repository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Funcionário não encontrado"
                ));

        String cpf = normalizarCpf(dados.getCpf());

        if (repository.existsByCpf(cpf)
                && !cpf.equals(atual.getCpf())) {
            return ResponseEntity.status(HttpStatus.CONFLICT)
                    .body("Já existe um funcionário com esse CPF");
        }

        atual.setNome(dados.getNome());
        atual.setCpf(cpf);

        try {
            return ResponseEntity.ok(repository.save(atual));
        } catch (DataIntegrityViolationException e) {
            return ResponseEntity.status(HttpStatus.CONFLICT)
                    .body("Já existe um funcionário com esse CPF");
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> excluir(@PathVariable Long id) {
        if (!repository.existsById(id)) {
            throw new ResponseStatusException(
                    HttpStatus.NOT_FOUND, "Funcionário não encontrado"
            );
        }

        repository.deleteById(id);
        return ResponseEntity.noContent().build();
    }

    private String normalizarCpf(String cpf) {
        return cpf == null ? "" : cpf.replaceAll("\\D", "");
    }
}
