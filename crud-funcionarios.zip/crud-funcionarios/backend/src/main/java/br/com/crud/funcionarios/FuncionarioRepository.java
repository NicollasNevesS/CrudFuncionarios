
package br.com.crud.funcionarios;

import org.springframework.data.jpa.repository.JpaRepository;

public interface FuncionarioRepository
        extends JpaRepository<Funcionario, Long> {

    boolean existsByCpf(String cpf);
}
